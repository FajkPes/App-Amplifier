package cz.motiongrid.app;

/** All matrices are row-major. R maps phone axes into Android world axes. */
public final class MotionMath {
    private MotionMath() { }
    public static float[] mul(float[] matrix, float[] vector) {
        return new float[] {
            matrix[0]*vector[0]+matrix[1]*vector[1]+matrix[2]*vector[2],
            matrix[3]*vector[0]+matrix[4]*vector[1]+matrix[5]*vector[2],
            matrix[6]*vector[0]+matrix[7]*vector[1]+matrix[8]*vector[2]
        };
    }
    /** R_relative = R_reference^T × R_current. */
    public static float[] relativeRotation(float[] reference, float[] current) {
        float[] result=new float[9];
        for(int row=0;row<3;row++)for(int col=0;col<3;col++) {
            float value=0f;
            for(int k=0;k<3;k++)value+=reference[3*k+row]*current[3*k+col];
            result[3*row+col]=value;
        }
        return result;
    }
    /** a in coordinates of the anchored phone orientation. */
    public static float[] anchorVector(float[] reference, float[] current, float[] deviceVector) {
        return mul(relativeRotation(reference,current),deviceVector);
    }
    /** Gravity / static accelerometer reading in current phone coordinates. */
    public static float[] deviceGravity(float[] rotation, float g) {
        return new float[]{rotation[6]*g,rotation[7]*g,rotation[8]*g};
    }
}
