package cz.motiongrid.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Offline sensor console. Native code alone touches hardware; the asset-hosted
 * WebView is rendering-only. No INTERNET permission, no remote pages.
 */
public final class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private static final int LOCATION_PERMISSION_REQUEST = 71;
    private static final int EXPORT_DOCUMENT_REQUEST = 72;
    private static final long PUSH_INTERVAL_NS = 33_000_000L;
    private static final float GRAVITY = 9.80665f;
    private WebView web;
    private SensorManager sensors;
    private LocationManager locationManager;
    private Sensor accelerometer, linearSensor, gravitySensor, gyroSensor, gameRotation, fullRotation, magnetic;
    private Sensor orientationSensor;
    private final float[] accel = new float[3], linear = new float[3], grav = new float[3], gyro = new float[3], mag = new float[3];
    private final float[] rotation = new float[9], zero = new float[9];
    private boolean rotationReady = false, anchorReady = false, hasAccel = false, hasLinear = false,
            hasGravity = false, hasGyro = false, hasMag = false, pageReady = false;
    private boolean recording = false;
    private BufferedWriter recordWriter;
    private File recordFile;
    private long lastPushNs = 0, lastFlushMs = 0, recordingStartMs = 0;
    private int recordedSamples = 0;
    private Location lastLocation;
    private String orientationSource = "NONE";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9, 14, 23));
        getWindow().setNavigationBarColor(Color.rgb(9, 14, 23));
        sensors = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        accelerometer = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        linearSensor = sensors.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        gravitySensor = sensors.getDefaultSensor(Sensor.TYPE_GRAVITY);
        gyroSensor = sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        gameRotation = sensors.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        fullRotation = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        magnetic = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        orientationSensor = gameRotation != null ? gameRotation : fullRotation;
        if (orientationSensor != null) {
            orientationSource = (orientationSensor == gameRotation) ? "GAME_ROTATION_VECTOR" : "ROTATION_VECTOR";
        } else if (accelerometer != null && magnetic != null) {
            orientationSource = "ACCEL_MAG_FALLBACK";
        }
        for (int i = 0; i < 3; i++) { rotation[i * 3 + i] = 1; zero[i * 3 + i] = 1; }
        recordFile = new File(getFilesDir(), "motiongrid-last.csv");
        recordedSamples = getPreferences(MODE_PRIVATE).getInt("record_count", 0);
        if (!recordFile.exists()) recordedSamples = 0;

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(9, 14, 23));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) web.setImportantForAutofill(WebView.IMPORTANT_FOR_AUTOFILL_NO);
        web.addJavascriptInterface(new Bridge(), "MotionGridAndroid");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (!url.startsWith("file:///android_asset/")) return;
                pageReady = true;
                sendStatus();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return true; }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) { return true; }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onResume() {
        super.onResume();
        register(accelerometer);
        register(linearSensor);
        register(gravitySensor);
        register(gyroSensor);
        register(orientationSensor);
        if (orientationSensor == null) register(magnetic);
        startLocationIfAllowed();
    }

    private void register(Sensor s) { if (s != null) sensors.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME); }

    @Override public void onPause() {
        sensors.unregisterListener(this);
        locationManager.removeUpdates(this);
        stopRecording();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("MotionGridAndroid"); web.destroy(); }
        super.onDestroy();
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override public void onSensorChanged(SensorEvent event) {
        switch (event.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER:
                System.arraycopy(event.values, 0, accel, 0, 3); hasAccel = true;
                if (orientationSensor == null) calculateFallbackRotation();
                break;
            case Sensor.TYPE_LINEAR_ACCELERATION:
                System.arraycopy(event.values, 0, linear, 0, 3); hasLinear = true; break;
            case Sensor.TYPE_GRAVITY:
                System.arraycopy(event.values, 0, grav, 0, 3); hasGravity = true; break;
            case Sensor.TYPE_GYROSCOPE:
                System.arraycopy(event.values, 0, gyro, 0, 3); hasGyro = true; break;
            case Sensor.TYPE_GAME_ROTATION_VECTOR:
            case Sensor.TYPE_ROTATION_VECTOR:
                if (event.sensor == orientationSensor) {
                    SensorManager.getRotationMatrixFromVector(rotation, event.values);
                    rotationReady = true;
                    if (!anchorReady) resetAnchor();
                }
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                System.arraycopy(event.values, 0, mag, 0, 3); hasMag = true;
                calculateFallbackRotation();
                break;
        }
        if (event.timestamp - lastPushNs >= PUSH_INTERVAL_NS) {
            lastPushNs = event.timestamp;
            emitPacket(event.timestamp);
        }
    }

    private void calculateFallbackRotation() {
        if (orientationSensor == null && hasAccel && hasMag
                && SensorManager.getRotationMatrix(rotation, null, accel, mag)) {
            rotationReady = true;
            if (!anchorReady) resetAnchor();
        }
    }

    private void resetAnchor() {
        if (!rotationReady) return;
        System.arraycopy(rotation, 0, zero, 0, 9);
        anchorReady = true;
    }

    // Frame mathematics live in a JVM-testable class (no Android dependencies).
    private float[] anchorVector(float[] vector) {
        return MotionMath.anchorVector(zero, rotation, vector);
    }
    private float[] anchoredRotation() {
        return MotionMath.relativeRotation(zero, rotation);
    }

    private float[] sensorLinear() {
        if (hasLinear && linearSensor != null) return linear.clone();
        if (!hasAccel) return new float[] {0f, 0f, 0f};
        float[] gravityDevice;
        if (hasGravity && gravitySensor != null) gravityDevice = grav;
        else if (rotationReady) {
            // R^T * [0, 0, g]. Stationary accelerometer should read this vector.
            gravityDevice = MotionMath.deviceGravity(rotation, GRAVITY);
        } else return new float[] {0f, 0f, 0f};
        return new float[] {accel[0] - gravityDevice[0], accel[1] - gravityDevice[1], accel[2] - gravityDevice[2]};
    }

    private void emitPacket(long timestampNs) {
        if (!pageReady) return;
        try {
            JSONObject p = new JSONObject();
            p.put("t", timestampNs / 1e9);
            p.put("accelerometer", hasAccel ? arr(accel) : JSONObject.NULL);
            p.put("linearDevice", (hasLinear || (hasAccel && (hasGravity || rotationReady))) ? arr(sensorLinear()) : JSONObject.NULL);
            p.put("gyroDevice", hasGyro ? arr(gyro) : JSONObject.NULL);
            p.put("rotationAvailable", rotationReady);
            p.put("orientationSource", orientationSource);
            if (rotationReady) {
                p.put("matrix", arr(anchoredRotation()));
                p.put("linearReference", arr(anchorVector(sensorLinear())));
                if (hasGyro) p.put("gyroReference", arr(anchorVector(gyro)));
            }
            Location loc = lastLocation;
            if (loc != null) {
                long ageMs = (SystemClock.elapsedRealtimeNanos() - loc.getElapsedRealtimeNanos()) / 1_000_000;
                if (ageMs >= 0 && ageMs < 12000 && loc.hasSpeed()) {
                    p.put("gpsSpeedMps", loc.getSpeed());
                    p.put("gpsAccuracyM", loc.hasAccuracy() ? loc.getAccuracy() : JSONObject.NULL);
                    p.put("gpsAgeMs", ageMs);
                }
            }
            p.put("gpsAllowed", hasLocationPermission());
            p.put("recording", recording);
            p.put("recordedSamples", recordedSamples);
            if (recording) writeRecording(p);
            push("onSensor", p);
        } catch (Exception e) { /* One malformed sample must not halt sensors. */ }
    }

    private static JSONArray arr(float[] values) throws JSONException {
        JSONArray a = new JSONArray();
        for (float v : values) a.put(Float.isFinite(v) ? (double) v : JSONObject.NULL);
        return a;
    }

    private void push(String function, JSONObject object) {
        if (pageReady) web.evaluateJavascript("window.MotionGridNative&&window.MotionGridNative." + function + "(" + object.toString() + ")", null);
    }

    private void sendStatus() {
        try {
            JSONObject p = new JSONObject();
            p.put("hasAccelerometer", accelerometer != null);
            p.put("hasGyro", gyroSensor != null);
            p.put("hasLinear", linearSensor != null);
            p.put("orientationSource", orientationSource);
            p.put("gpsAllowed", hasLocationPermission());
            p.put("recording", recording);
            p.put("recordExists", recordFile.exists() && recordedSamples > 0);
            p.put("recordedSamples", recordedSamples);
            push("onStatus", p);
        } catch (JSONException ignored) { }
    }

    private boolean hasLocationPermission() {
        // A coarse/approximate-only grant does not guarantee GPS_PROVIDER access.
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestLocation() {
        if (!hasLocationPermission()) {
            requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST);
        } else startLocationIfAllowed();
    }

    private void startLocationIfAllowed() {
        if (!hasLocationPermission()) return;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 700, 0f, this);
            sendStatus();
        } catch (SecurityException | IllegalArgumentException ex) {
            toast("Polohové služby nejsou dostupné.");
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (hasLocationPermission()) startLocationIfAllowed();
            else toast("Bez polohy není dostupná GPS rychlost.");
            sendStatus();
        }
    }
    @Override public void onLocationChanged(Location location) {
        if (LocationManager.GPS_PROVIDER.equals(location.getProvider()) && location.hasSpeed()
                && (lastLocation == null || location.getElapsedRealtimeNanos() >= lastLocation.getElapsedRealtimeNanos()))
            lastLocation = location;
    }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) lastLocation = null;
    }
    @SuppressWarnings("deprecation")
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    private void startRecording() {
        stopRecording();
        try {
            recordWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(recordFile, false), StandardCharsets.UTF_8), 16384);
            recordWriter.write("elapsed_s,ax_device,ay_device,az_device,ax_reference,ay_reference,az_reference,gx_rad_s,gy_rad_s,gz_rad_s,gps_m_s,r00,r01,r02,r10,r11,r12,r20,r21,r22\n");
            recordedSamples = 0;
            getPreferences(MODE_PRIVATE).edit().putInt("record_count", 0).apply();
            recordingStartMs = SystemClock.elapsedRealtime();
            lastFlushMs = recordingStartMs;
            recording = true;
            sendStatus();
        } catch (Exception e) { recording = false; recordWriter = null; toast("Nelze zahájit záznam: " + e.getMessage()); }
    }
    private void writeRecording(JSONObject p) {
        if (recordWriter == null) return;
        try {
            StringBuilder line = new StringBuilder(300);
            appendNumber(line, (SystemClock.elapsedRealtime() - recordingStartMs) / 1000.0);
            appendArray(line, p.optJSONArray("linearDevice"), 3);
            appendArray(line, p.optJSONArray("linearReference"), 3);
            appendArray(line, p.optJSONArray("gyroDevice"), 3);
            appendNumber(line, p.optDouble("gpsSpeedMps", Double.NaN));
            appendArray(line, p.optJSONArray("matrix"), 9);
            line.append('\n');
            recordWriter.write(line.toString());
            recordedSamples++;
            if (SystemClock.elapsedRealtime() - lastFlushMs > 1000) {
                recordWriter.flush(); lastFlushMs = SystemClock.elapsedRealtime();
                if (recordedSamples % 90 < 31) getPreferences(MODE_PRIVATE).edit().putInt("record_count", recordedSamples).apply();
            }
        } catch (Exception e) { stopRecording(); toast("Záznam přerušen: " + e.getMessage()); }
    }
    private static void appendArray(StringBuilder sb, JSONArray ar, int n) {
        for (int i = 0; i < n; i++) appendNumber(sb, ar == null ? Double.NaN : ar.optDouble(i, Double.NaN));
    }
    private static void appendNumber(StringBuilder sb, double val) {
        if (sb.length() > 0 && sb.charAt(sb.length() - 1) != '\n') sb.append(',');
        if (Double.isFinite(val)) sb.append(String.format(Locale.US, "%.6f", val));
    }
    private void stopRecording() {
        recording = false;
        if (recordWriter != null) {
            try { recordWriter.flush(); recordWriter.close(); } catch (Exception ignored) { }
            recordWriter = null;
        }
        if (recordFile != null) getPreferences(MODE_PRIVATE).edit().putInt("record_count", recordedSamples).apply();
        sendStatus();
    }
    private void exportCsv() {
        if (!recordFile.exists() || recordedSamples == 0) {
            toast("Nejdřív vytvoř záznam."); return;
        }
        if (recording && recordWriter != null) {
            try { recordWriter.flush(); } catch (Exception ignored) { }
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "MotionGrid-" + System.currentTimeMillis() + ".csv");
        startActivityForResult(intent, EXPORT_DOCUMENT_REQUEST);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_DOCUMENT_REQUEST || resultCode != RESULT_OK || data == null) return;
        Uri dest = data.getData();
        if (dest == null) return;
        try (FileInputStream input = new FileInputStream(recordFile); OutputStream output = getContentResolver().openOutputStream(dest)) {
            if (output == null) throw new IllegalStateException("Nelze otevřít výstup.");
            byte[] buf = new byte[8192]; int n;
            while ((n = input.read(buf)) != -1) output.write(buf, 0, n);
            toast("CSV bylo uloženo.");
        } catch (Exception ex) { toast("Export se nezdařil: " + ex.getMessage()); }
    }
    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }

    private final class Bridge {
        @JavascriptInterface public void align() { runOnUiThread(() -> { resetAnchor(); sendStatus(); }); }
        @JavascriptInterface public void requestGps() { runOnUiThread(() -> requestLocation()); }
        @JavascriptInterface public void setRecording(boolean enabled) { runOnUiThread(() -> { if (enabled) startRecording(); else stopRecording(); }); }
        @JavascriptInterface public void exportCsv() { runOnUiThread(() -> exportCsv()); }
        @JavascriptInterface public void getStatus() { runOnUiThread(() -> sendStatus()); }
    }
}
