/* MotionGrid UI. Native mode: no synthetic sensor values. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const DEG = 180 / Math.PI;
const colors = ['#67cdfb','#91e5ad','#ffb77a'];
const identity = () => [1,0,0, 0,1,0, 0,0,1];
const native = typeof window.MotionGridAndroid !== 'undefined';
const state = {
  packet:null, status:null, orientation:identity(), history:[],
  lastPacketAt:0, measuredHz:0, sampleCounter:0, hzWindow:performance.now(),
  toastTimer:null, recording:false, recCount:0, recordRows:[],
  webR:identity(), webZero:null, webReady:false,
  webDevice:null, webGyro:null, webGps:null, webGpsAccuracy:null, webGpsAllowed:false,
  webPermissionPending:false
};

function showToast(message) {
  const node=$('toast'); node.textContent=message; node.classList.add('show');
  clearTimeout(state.toastTimer); state.toastTimer=setTimeout(()=>node.classList.remove('show'),3300);
}
function num(x,digits=2) { return Number.isFinite(x) ? x.toFixed(digits) : '—'; }
function magnitude(v){ return v && v.every(Number.isFinite)? Math.hypot(...v):null; }
function matrixMul(a,b) {
  const r=Array(9).fill(0);
  for(let i=0;i<3;i++)for(let j=0;j<3;j++)for(let k=0;k<3;k++)r[3*i+j]+=a[3*i+k]*b[3*k+j];
  return r;
}
function trans(a){return [a[0],a[3],a[6],a[1],a[4],a[7],a[2],a[5],a[8]];}
function matVec(a,v){return [a[0]*v[0]+a[1]*v[1]+a[2]*v[2],a[3]*v[0]+a[4]*v[1]+a[5]*v[2],a[6]*v[0]+a[7]*v[1]+a[8]*v[2]];}
function finiteVec(v,n){return Array.isArray(v)&&v.length===n&&v.every(Number.isFinite);}
function getAngles(r) {
  // R = Rz(yaw) * Ry(pitch) * Rx(roll), relative to calibration.
  return [Math.atan2(r[7],r[8])*DEG, Math.asin(Math.max(-1,Math.min(1,-r[6])))*DEG, Math.atan2(r[3],r[0])*DEG];
}
function sourceLabel(source) {
  if(source==='GAME_ROTATION_VECTOR') return 'GYRO + AKCEL · FÚZE';
  if(source==='ROTATION_VECTOR') return 'GYRO + AKCEL + MAG';
  if(source==='ACCEL_MAG_FALLBACK') return 'BEZ GYRO FÚZE';
  if(source==='WEB_ORIENTATION') return 'WEB · ORIENTACE';
  return 'NENÍ ORIENTACE';
}

window.MotionGridNative={
  onStatus(s) {
    state.status=s;
    $('sensorInfo').textContent =
      `Akcel ${s.hasAccelerometer?'✓':'✕'} · Gyro ${s.hasGyro?'✓':'✕'} · Fúze: ${sourceLabel(s.orientationSource)}`;
    $('gpsBtn').textContent = s.gpsAllowed ? 'GPS povoleno ✓' : 'Zapnout GPS ↗';
    if(s.recordExists) $('exportBtn').disabled=false;
    state.recording=!!s.recording;
    state.recCount=s.recordedSamples||0;
    updateRecordingUI();
    if (s.orientationSource==='NONE') $('orientationStatus').textContent='FÚZE NEDOSTUPNÁ';
  },
  onSensor(packet) { ingest(packet); }
};

function ingest(p) {
  if(!p || !Number.isFinite(p.t)) return;
  state.packet=p;
  state.lastPacketAt=performance.now();
  if(finiteVec(p.matrix,9)) state.orientation=p.matrix;
  state.sampleCounter++;
  const now=performance.now();
  if(now-state.hzWindow>=1200){state.measuredHz=Math.round(state.sampleCounter*1000/(now-state.hzWindow));state.sampleCounter=0;state.hzWindow=now;}
  if(finiteVec(p.linearReference,3)) {
    state.history.push({t:p.t, v:p.linearReference.slice()});
    while(state.history.length && state.history[0].t<p.t-10.5)state.history.shift();
  }
  if (!native && state.recording) {
    const acc=p.linearReference||p.linearDevice||[null,null,null];
    const g=p.gyroDevice||[null,null,null];
    const r=p.matrix||identity();
    state.recordRows.push([p.t,...acc,...g,p.gpsSpeedMps??null,...r]);
    if(state.recordRows.length>20000){state.recordRows.shift();showToast('Web záznam má limit 20 000 vzorků. Exportuj CSV.');}
    state.recCount=state.recordRows.length;
  } else if(native && Number.isFinite(p.recordedSamples)) state.recCount=p.recordedSamples;
  updateValues();
}

function setBar(id, v) {
  const el=$(id);
  if(!Number.isFinite(v)){el.style.width='0';return;}
  const size=Math.min(50,Math.abs(v)*5);
  el.style.left=(v<0?50-size:50)+'%';
  el.style.width=size+'%';
}
function updateValues() {
  const p=state.packet;
  if(!p)return;
  const valid=!!p.rotationAvailable&&finiteVec(p.matrix,9);
  $('liveIndicator').classList.add('active'); $('liveText').textContent='ŽIVĚ';
  const os=$('orientationStatus'); os.textContent=sourceLabel(p.orientationSource); os.classList.toggle('ready',valid);
  const a=valid&&finiteVec(p.linearReference,3)?p.linearReference:null;
  const g=finiteVec(p.gyroDevice,3)?p.gyroDevice.map(x=>x*DEG):null;
  ['X','Y','Z'].forEach((axis,i)=> {
    $('acc'+axis).textContent=num(a?.[i]); setBar('bar'+axis,a?.[i]);
    $('gyro'+axis).textContent=num(g?.[i],1);
  });
  $('totalAccel').textContent=num(magnitude(a));
  $('totalGyro').textContent=num(magnitude(g),1);
  if(valid){
    const ang=getAngles(p.matrix);
    $('roll').textContent=num(ang[0],1);$('pitch').textContent=num(ang[1],1);$('yaw').textContent=num(ang[2],1);
  }
  const speed=p.gpsSpeedMps;
  const hasSpeed=Number.isFinite(speed)&&speed>=0;
  $('gpsSpeed').textContent=hasSpeed?num(speed*3.6,1):'—';
  $('gpsMps').textContent=hasSpeed?`${num(speed)} m/s`:'— m/s';
  $('gpsIndicator').textContent=hasSpeed?'GPS FIX · ŽIVĚ':'GPS BEZ FIXU';
  $('gpsIndicator').classList.toggle('fix',hasSpeed);
  $('gpsDetail').textContent=hasSpeed?
     `Přesnost polohy: ${num(p.gpsAccuracyM,0)} m · vzorek ${num((p.gpsAgeMs??0)/1000,1)} s`:
     p.gpsAllowed?'Čeká se na satelity / přesnou rychlost.':'Bez GPS není dostupná skutečná rychlost.';
  if(p.gpsAllowed) $('gpsBtn').textContent='GPS povoleno ✓';
  $('hzIndicator').textContent=`${state.measuredHz||'—'} Hz`;
  $('samples').textContent=state.recCount.toLocaleString('cs-CZ');
}
function updateRecordingUI() {
  const el=$('recBtn');
  el.classList.toggle('recording',state.recording);
  el.innerHTML=state.recording?'<span class="rec-circle"></span> Ukončit záznam':'<span class="rec-circle"></span> Zahájit záznam';
  $('sessionState').textContent=state.recording?'Probíhá':'Vypnuto';
  $('recTag').textContent=state.recording?'● NAHRÁVÁNÍ':'PŘIPRAVENO';
  $('recTag').classList.toggle('recording',state.recording);
  $('samples').textContent=state.recCount.toLocaleString('cs-CZ');
  if(!native)$('exportBtn').disabled=state.recordRows.length===0;
}
function align() {
  if(native){window.MotionGridAndroid.align();showToast('Osy zarovnány k aktuální poloze telefonu.');}
  else if(state.webReady){state.webZero=state.webR.slice();showToast('Referenční soustava zarovnána.');}
  else enableBrowserSensors();
  state.history=[];
}
function toggleRecording() {
  if(native){
    if(!state.recording && state.recCount && !confirm('Nový záznam nahradí poslední neexportovaný. Pokračovat?'))return;
    window.MotionGridAndroid.setRecording(!state.recording);
  } else {
    if(!state.recording && state.recordRows.length && !confirm('Nový záznam nahradí poslední webový. Pokračovat?'))return;
    if(!state.recording) {state.recordRows=[];state.recCount=0;}
    state.recording=!state.recording;updateRecordingUI();
    showToast(state.recording?'Záznam zahájen (webový režim).':'Záznam ukončen.');
  }
}
function exportRecording() {
  if(native){window.MotionGridAndroid.exportCsv();return;}
  if(state.recordRows.length===0){showToast('Nemáš žádný záznam.');return;}
  const head='sensor_t_s,ax_reference,ay_reference,az_reference,gx_rad_s,gy_rad_s,gz_rad_s,gps_m_s,r00,r01,r02,r10,r11,r12,r20,r21,r22';
  const csv=[head,...state.recordRows.map(r=>r.map(v=>Number.isFinite(v)?Number(v).toFixed(6):'').join(','))].join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download=`MotionGrid-${Date.now()}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
$('alignBtn').addEventListener('click',align);
$('gpsBtn').addEventListener('click',()=>{
  if(native){window.MotionGridAndroid.requestGps();return;}
  if(!navigator.geolocation){showToast('GPS v prohlížeči není dostupné.');return;}
  navigator.geolocation.watchPosition(position=>{
    state.webGps=position.coords.speed;
    state.webGpsAccuracy=position.coords.accuracy;
    state.webGpsAllowed=true;
  },error=>showToast('GPS není dostupné: '+error.message),{enableHighAccuracy:true,maximumAge:1000,timeout:15000});
  showToast('Požádáno o GPS. Vyčkej na měření.');
});
$('recBtn').addEventListener('click',toggleRecording);
$('exportBtn').addEventListener('click',exportRecording);
$('exportBtn').disabled=true;

/* Sensor events fallback for mobile HTTPS browsers. Android APK uses Java sensor fusion above. */
function w3cRotation(alpha,beta,gamma) {
  const a=alpha/DEG,b=beta/DEG,g=gamma/DEG;
  const ca=Math.cos(a),sa=Math.sin(a),cb=Math.cos(b),sb=Math.sin(b),cg=Math.cos(g),sg=Math.sin(g);
  return [ca*cg-sa*sb*sg,-sa*cb,ca*sg+sa*sb*cg,
          sa*cg+ca*sb*sg,ca*cb,sa*sg-ca*sb*cg,
          -cb*sg,sb,cb*cg];
}
function onWebMotion(e) {
  const a=e.acceleration;
  state.webDevice=a&&[a.x,a.y,a.z].every(Number.isFinite)?[a.x,a.y,a.z]:null;
  const rr=e.rotationRate;
  state.webGyro=rr&&[rr.beta,rr.gamma,rr.alpha].every(Number.isFinite)?[rr.beta/DEG,rr.gamma/DEG,rr.alpha/DEG]:null;
  sendWebFrame();
}
function onWebOrientation(e) {
  if(![e.alpha,e.beta,e.gamma].every(Number.isFinite))return;
  state.webR=w3cRotation(e.alpha,e.beta,e.gamma);state.webReady=true;
  if(!state.webZero)state.webZero=state.webR.slice();
  sendWebFrame();
}
let lastWebFrameTime=0;
function sendWebFrame() {
  const now=performance.now();
  if(now-lastWebFrameTime<34)return;
  lastWebFrameTime=now;
  const rotated=state.webReady&&state.webZero?matrixMul(trans(state.webZero),state.webR):null;
  const a=state.webDevice;
  const p={t:now/1000,linearDevice:a,accelerometer:null,gyroDevice:state.webGyro,
    rotationAvailable:!!rotated,orientationSource:'WEB_ORIENTATION',gpsAllowed:state.webGpsAllowed};
  if(rotated){p.matrix=rotated;if(a)p.linearReference=matVec(rotated,a);}
  if(Number.isFinite(state.webGps)){p.gpsSpeedMps=state.webGps;p.gpsAccuracyM=state.webGpsAccuracy;p.gpsAgeMs=0;}
  ingest(p);
}
async function enableBrowserSensors() {
  if(state.webPermissionPending)return;
  state.webPermissionPending=true;
  try {
    if(typeof DeviceMotionEvent!=='undefined'&&typeof DeviceMotionEvent.requestPermission==='function'){
      const result=await DeviceMotionEvent.requestPermission();
      if(result!=='granted')throw new Error('Přístup k pohybu zamítnut.');
    }
    if(typeof DeviceOrientationEvent!=='undefined'&&typeof DeviceOrientationEvent.requestPermission==='function'){
      const result=await DeviceOrientationEvent.requestPermission();
      if(result!=='granted')throw new Error('Přístup k orientaci zamítnut.');
    }
    window.addEventListener('devicemotion',onWebMotion,{passive:true});
    window.addEventListener('deviceorientation',onWebOrientation,{passive:true});
    showToast('Webové senzory aktivovány. Použij APK pro přesnější fúzi.');
  }catch(e){showToast(e.message||'Senzory nejsou povoleny.');}
  state.webPermissionPending=false;
}
if(!native){
  $('sensorInfo').textContent='WEB NÁHLED · pro fúzi senzorů použij Android aplikaci';
  $('orientationStatus').textContent='WEB REŽIM';
  $('alignBtn').textContent='◎ Povolit / zarovnat';
  // Android Chrome allows sensor events in a secure context without prompts.
  if(typeof DeviceMotionEvent!=='undefined' && typeof DeviceMotionEvent.requestPermission!=='function')enableBrowserSensors();
  updateRecordingUI();
} else window.MotionGridAndroid.getStatus();

/* 3D device axes: relative rotation matrix in a fixed anchored world frame. */
const canvas=$('space'), ctx=canvas.getContext('2d');
const chart=$('chart'), cctx=chart.getContext('2d');
function fitCanvas(el) {
  const rect=el.getBoundingClientRect();const ratio=Math.min(2,window.devicePixelRatio||1);
  const width=Math.max(1,Math.round(rect.width*ratio)),height=Math.max(1,Math.round(rect.height*ratio));
  if(el.width!==width||el.height!==height){el.width=width;el.height=height;}
  return {w:rect.width,h:rect.height,ratio};
}
function project(v,w,h,scale) {
  // Fixed orthographic view: same camera while axes and phone rotate.
  const right=[0.79,0,-0.61],up=[-0.26,0.91,-0.34];
  return [w*.5+(v[0]*right[0]+v[1]*right[1]+v[2]*right[2])*scale,
          h*.52-(v[0]*up[0]+v[1]*up[1]+v[2]*up[2])*scale];
}
function linePath(context,from,to,color,width=1,dash=[]) {
  context.beginPath();context.setLineDash(dash);context.moveTo(...from);context.lineTo(...to);
  context.strokeStyle=color;context.lineWidth=width;context.stroke();context.setLineDash([]);
}
function drawSpace(time) {
  const {w,h,ratio}=fitCanvas(canvas);ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,w,h);
  const scale=Math.min(w*.18,h*.265);
  // Faint reference floor / depth grid.
  for(let k=-3;k<=3;k++){
    const v=k*.4;
    linePath(ctx,project([-1.2,-.98,v],w,h,scale),project([1.2,-.98,v],w,h,scale),'#2e475554',1);
    linePath(ctx,project([v,-.98,-1.2],w,h,scale),project([v,-.98,1.2],w,h,scale),'#2e475554',1);
  }
  const origin=project([0,0,0],w,h,scale);
  const unit=[[1,0,0],[0,1,0],[0,0,1]];
  for(let i=0;i<3;i++){
    const a=unit[i];const p=project(a.map(x=>x*1.55),w,h,scale);
    linePath(ctx,origin,p,colors[i]+'42',1.6,[4,5]);
    ctx.font='700 10px Arial';ctx.textAlign='center';ctx.fillStyle=colors[i]+'88';
    ctx.fillText(['X₀','Y₀','Z₀'][i],p[0]+6,p[1]-3);
  }
  const ready=!!state.packet?.rotationAvailable;
  const R=ready?state.orientation:identity();
  const axes=unit.map((_,i)=>[R[i],R[3+i],R[6+i]]);
  const sorted=axes.map((vec,i)=>({vec,i,depth:vec[2]})).sort((a,b)=>a.depth-b.depth);
  for(const a of sorted){
    const end=project(a.vec.map(x=>x*1.17),w,h,scale);
    const back=project(a.vec.map(x=>x*-.47),w,h,scale);
    const color=colors[a.i];
    linePath(ctx,back,origin,color+'50',2);
    linePath(ctx,origin,end,ready?color:color+'66',4);
    // Arrowhead follows the projected shaft.
    const ang=Math.atan2(end[1]-origin[1],end[0]-origin[0]);
    ctx.beginPath();ctx.moveTo(...end);ctx.lineTo(end[0]-11*Math.cos(ang-.5),end[1]-11*Math.sin(ang-.5));
    ctx.lineTo(end[0]-11*Math.cos(ang+.5),end[1]-11*Math.sin(ang+.5));ctx.closePath();ctx.fillStyle=color;ctx.fill();
    const label=project(a.vec.map(x=>x*1.40),w,h,scale);
    ctx.font='800 15px Arial';ctx.fillStyle=ready?color:'#607a88';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(['X','Y','Z'][a.i],label[0],label[1]);
  }
  ctx.beginPath();ctx.arc(...origin,5,0,Math.PI*2);ctx.fillStyle='#e7f5fc';ctx.fill();
  ctx.beginPath();ctx.arc(...origin,9,0,Math.PI*2);ctx.strokeStyle='#8cb1bc55';ctx.lineWidth=1.5;ctx.stroke();
  // World acceleration arrow, stays in aligned reference frame.
  const acceleration=state.packet?.linearReference;
  const amp=magnitude(acceleration);
  if(ready&&Number.isFinite(amp)&&amp>.24){
    const length=Math.min(1.2,amp/3.5);
    const end=project(acceleration.map(x=>x/amp*length),w,h,scale);
    linePath(ctx,origin,end,'#f7fbffcf',2,[4,3]);
    ctx.beginPath();ctx.arc(...end,4,0,Math.PI*2);ctx.fillStyle='#f6ffff';ctx.fill();
  }
  if(!ready){ctx.font='600 11px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#8398ac';ctx.fillText('Čeká se na data orientace…',w/2,h*.88);}
}
function drawChart() {
  const {w,h,ratio}=fitCanvas(chart);cctx.setTransform(ratio,0,0,ratio,0,0);cctx.clearRect(0,0,w,h);
  const left=5,right=w-7,top=6,bottom=h-15;
  const points=state.history;const now=points.length?points[points.length-1].t:0;
  let highest=0;for(const sample of points)for(const value of sample.v)highest=Math.max(highest,Math.abs(value));
  const scale=highest<=2?2:highest<=5?5:highest<=10?10:Math.ceil(highest/10)*10;
  $('chartScale').textContent=String(scale);
  for(let k=0;k<=4;k++){
    let y=top+(bottom-top)*k/4;
    linePath(cctx,[left,y],[right,y],k===2?'#4f688066':'#3851644c',1,k===2?[]:[2,4]);
  }
  for(let k=0;k<=5;k++){
    const x=left+(right-left)*k/5;
    linePath(cctx,[x,top],[x,bottom],'#38516436',1,[2,4]);
  }
  if(points.length<2)return;
  points.forEach((_,i)=>{ /* series chart is deliberately native Canvas: no external SDK */ });
  for(let axis=0;axis<3;axis++){
    cctx.beginPath();let started=false;
    for(const sample of points){
      const x=right-(now-sample.t)/10*(right-left);
      const v=sample.v[axis];if(x<left||!Number.isFinite(v))continue;
      const y=(top+bottom)/2-Math.max(-scale,Math.min(scale,v))/scale*(bottom-top)/2;
      if(!started){cctx.moveTo(x,y);started=true;}else cctx.lineTo(x,y);
    }
    cctx.strokeStyle=colors[axis];cctx.lineWidth=1.6;cctx.lineJoin='round';cctx.stroke();
  }
  cctx.font='9px Arial';cctx.fillStyle='#71889b';cctx.textAlign='left';cctx.fillText('−10 s',left,bottom+12);
  cctx.textAlign='right';cctx.fillText('NYNÍ',right,bottom+12);
}
function render(t){
  drawSpace(t);drawChart();
  if(state.packet && performance.now()-state.lastPacketAt>3000){
    $('liveIndicator').classList.remove('active');$('liveText').textContent='BEZ DAT';
    $('hzIndicator').textContent='— Hz';
  }
  requestAnimationFrame(render);
}
requestAnimationFrame(render);

// Expose deterministic math for offline unit tests, not to UI users.
window.MotionGridMath={matrixMul,trans,matVec,getAngles,w3cRotation};
})();
